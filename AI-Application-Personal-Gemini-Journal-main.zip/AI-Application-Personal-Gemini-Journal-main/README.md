# Gemini Reflection Journal

A secure, user-authenticated reflection and journaling application powered by **Gemini 3.6 Flash** and **Google Cloud Firestore**, featuring strict user data isolation and resilient multi-model AI fallbacks.

---

## Architecture Overview

- **Frontend Client**: React 19 + TypeScript + Vite + Tailwind CSS with modern typography, keyboard shortcuts, markdown export, and real-time Firestore listeners.
- **Backend API**: Express server running on Node.js / tsx hosting `/api/gemini/reflect` with resilient fallback ladder (`gemini-3.6-flash` → `gemini-3.1-flash-lite` → `gemini-flash-latest` → `gemini-3.7-flash`).
- **User Authentication**: Firebase Authentication (Google Sign-In & guest session sandbox) with zero password storage.
- **Database & Isolation**: Cloud Firestore with owner-bound security rules restricting each user to `/users/{userId}/interactions/{interactionId}`.
- **Secret Management**: Google Cloud Secret Manager for server-side `GEMINI_API_KEY` protection.

---

## 1. Environment & Prerequisites

1. **Google Cloud SDK**: Install the `gcloud` CLI and log in:
   ```bash
   gcloud auth login
   gcloud config set project YOUR_PROJECT_ID
   ```
2. **Enable Required Google Cloud APIs**:
   ```bash
   gcloud services enable \
     run.googleapis.com \
     secretmanager.googleapis.com \
     firestore.googleapis.com \
     aiplatform.googleapis.com
   ```
3. **Node.js**: Ensure Node.js 20+ is installed locally.

---

## 2. Database Security Configuration (Cloud Firestore)

Deploy secure, owner-bound Firestore rules that enforce zero insecure defaults:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Default Deny
    match /{document=**} {
      allow read, write: if false;
    }

    // User Data Isolation
    match /users/{userId}/interactions/{interactionId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }

    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

To deploy rules directly with Firebase CLI:
```bash
firebase deploy --only firestore:rules
```

---

## 3. Secret Management Setup (Google Cloud Secret Manager)

Create and populate the `GEMINI_API_KEY` secret, then grant your Cloud Run compute service account access:

```bash
# 1. Create and populate the secret
gcloud secrets create GEMINI_API_KEY --replication-policy="automatic"
echo -n "YOUR_API_KEY" | gcloud secrets versions add GEMINI_API_KEY --data-file=-

# 2. Retrieve your project number
PROJECT_NUMBER=$(gcloud projects describe $(gcloud config get-value project) --format="value(projectNumber)")

# 3. Grant the default Cloud Run service account access to read the secret
gcloud secrets add-iam-policy-binding GEMINI_API_KEY \
  --member="serviceAccount:${PROJECT_NUMBER}-compute@developer.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"
```

---

## 4. Cloud Run Deployment Flow

Deploy the application as a containerized service on Cloud Run with the Secret Manager binding:

```bash
# Build and deploy directly using Cloud Build and Cloud Run
gcloud run deploy gemini-reflection-journal \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 3000 \
  --set-secrets="GEMINI_API_KEY=GEMINI_API_KEY:latest"
```

---

## 5. Required Campaign Labeling (Verification Binding)

Apply the mandatory verification resource label to register the service for automated challenge evaluation:

```bash
gcloud run services update gemini-reflection-journal \
  --update-labels=dev-tutorial=cloud-run-ai-challenge \
  --region=us-central1
```

---

## 6. Local Development

1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy environment file:
   ```bash
   cp .env.example .env
   # Add your GEMINI_API_KEY in .env
   ```
3. Run the development server:
   ```bash
   npm run dev
   ```
4. Access the web app at `http://localhost:3000`.

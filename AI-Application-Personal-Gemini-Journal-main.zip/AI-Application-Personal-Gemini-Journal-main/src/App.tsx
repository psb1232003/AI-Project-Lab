import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  auth,
  signInWithGoogle,
  signInAsDemo,
  logOut,
  getUserInteractionsRef,
  saveUserInteraction,
  deleteUserInteraction,
  mapFirebaseUser,
} from './lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { onSnapshot, query, orderBy } from 'firebase/firestore';
import { InteractionDoc, InteractionTurn, ReflectionMode, UserProfile } from './types';
import { LandingPage } from './components/LandingPage';
import { Navbar } from './components/Navbar';
import { HistorySidebar } from './components/HistorySidebar';
import { JournalWorkspace } from './components/JournalWorkspace';
import { Menu, Sparkles } from 'lucide-react';

function createNewInteractionTemplate(userId: string): InteractionDoc {
  const now = Date.now();
  return {
    id: 'reflection_' + Math.random().toString(36).substring(2, 9) + '_' + now,
    userId,
    title: 'New Reflection',
    summary: '',
    tags: ['Mindfulness'],
    mode: 'reflection',
    turns: [],
    createdAt: now,
    updatedAt: now,
  };
}

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  const [interactions, setInteractions] = useState<InteractionDoc[]>([]);
  const [activeInteractionId, setActiveInteractionId] = useState<string | null>(null);
  const [activeInteraction, setActiveInteraction] = useState<InteractionDoc | null>(null);

  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Reference to hold unsaved interaction for retry
  const pendingSaveRef = useRef<InteractionDoc | null>(null);

  // 1. Firebase Auth state listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      const mapped = mapFirebaseUser(user);
      setCurrentUser(mapped);
      setAuthLoading(false);
      setAuthError(null);
    });
    return () => unsubscribe();
  }, []);

  // 2. Real-time Firestore sync strictly isolated to /users/{uid}/interactions
  useEffect(() => {
    if (!currentUser?.uid) {
      setInteractions([]);
      setActiveInteractionId(null);
      setActiveInteraction(null);
      return;
    }

    try {
      const q = query(
        getUserInteractionsRef(currentUser.uid),
        orderBy('updatedAt', 'desc')
      );

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const docs: InteractionDoc[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as InteractionDoc;
            docs.push({
              ...data,
              id: docSnap.id,
            });
          });
          setInteractions(docs);

          // If no active interaction is chosen, or active was deleted, pick the latest or initialize new
          setActiveInteractionId((prevId) => {
            if (prevId && docs.some((d) => d.id === prevId)) {
              return prevId;
            }
            if (docs.length > 0) {
              return docs[0].id;
            }
            return null;
          });
        },
        (error) => {
          console.error('Firestore snapshot listener error:', error);
          // If permission denied or other Firestore error, escalate cleanly
          setSaveError('Firestore sync notice: ' + (error.message || 'Error reading documents'));
        }
      );

      return () => unsubscribe();
    } catch (err: any) {
      console.error('Error attaching Firestore listener:', err);
    }
  }, [currentUser?.uid]);

  // Keep activeInteraction in sync with interactions list or local state
  useEffect(() => {
    if (!activeInteractionId) {
      if (currentUser?.uid && interactions.length === 0) {
        const fresh = createNewInteractionTemplate(currentUser.uid);
        setActiveInteraction(fresh);
        setActiveInteractionId(fresh.id);
      } else if (interactions.length > 0) {
        setActiveInteraction(interactions[0]);
        setActiveInteractionId(interactions[0].id);
      } else {
        setActiveInteraction(null);
      }
    } else {
      const matched = interactions.find((i) => i.id === activeInteractionId);
      if (matched) {
        setActiveInteraction(matched);
      }
    }
  }, [activeInteractionId, interactions, currentUser?.uid]);

  // Handler: Google Sign In
  const handleGoogleSignIn = async () => {
    try {
      setAuthError(null);
      await signInWithGoogle();
    } catch (err: any) {
      setAuthError(err?.message || 'Failed to sign in with Google.');
      throw err;
    }
  };

  // Handler: Demo Sign In
  const handleDemoSignIn = async () => {
    try {
      setAuthError(null);
      await signInAsDemo();
    } catch (err: any) {
      setAuthError(err?.message || 'Failed to initialize demo session.');
      throw err;
    }
  };

  // Handler: Sign Out
  const handleSignOut = async () => {
    await logOut();
    setActiveInteraction(null);
    setActiveInteractionId(null);
    setInteractions([]);
  };

  // Handler: Create New Reflection
  const handleNewReflection = useCallback(() => {
    if (!currentUser?.uid) return;
    const fresh = createNewInteractionTemplate(currentUser.uid);
    setActiveInteraction(fresh);
    setActiveInteractionId(fresh.id);
    setSaveError(null);
    setSidebarOpen(false);
  }, [currentUser?.uid]);

  // Handler: Select an interaction from history
  const handleSelectInteraction = (id: string) => {
    setActiveInteractionId(id);
    setSaveError(null);
    setSidebarOpen(false);
  };

  // Handler: Delete an interaction
  const handleDeleteInteraction = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser?.uid) return;
    if (window.confirm('Are you sure you want to delete this reflection entry? This action cannot be undone.')) {
      try {
        await deleteUserInteraction(currentUser.uid, id);
        if (activeInteractionId === id) {
          const remaining = interactions.filter((i) => i.id !== id);
          if (remaining.length > 0) {
            setActiveInteractionId(remaining[0].id);
          } else {
            handleNewReflection();
          }
        }
      } catch (err: any) {
        console.error('Delete interaction failed:', err);
        setSaveError('Failed to delete interaction: ' + err.message);
      }
    }
  };

  // Handler: Save / Update active interaction document to Firestore
  const handleUpdateInteraction = async (updated: InteractionDoc) => {
    if (!currentUser?.uid) return;
    setActiveInteraction(updated);
    setIsSaving(true);
    setSaveError(null);
    pendingSaveRef.current = updated;

    try {
      await saveUserInteraction(currentUser.uid, updated);
      pendingSaveRef.current = null;
    } catch (err: any) {
      console.error('Save to Firestore failed:', err);
      setSaveError('Failed to save to Firestore. Your changes are preserved locally.');
    } finally {
      setIsSaving(false);
    }
  };

  // Handler: Retry Save for Guaranteed Transaction Verification
  const handleRetrySave = async () => {
    if (!currentUser?.uid || !pendingSaveRef.current) return;
    setIsSaving(true);
    setSaveError(null);
    try {
      await saveUserInteraction(currentUser.uid, pendingSaveRef.current);
      pendingSaveRef.current = null;
    } catch (err: any) {
      console.error('Retry save failed:', err);
      setSaveError('Retry failed: ' + (err?.message || 'Database write rejected'));
    } finally {
      setIsSaving(false);
    }
  };

  // Handler: Send Prompt to Gemini and persist multi-turn conversation
  const handleSendPrompt = async (prompt: string, mode: ReflectionMode) => {
    if (!currentUser?.uid || !activeInteraction) return;

    setIsGenerating(true);
    setSaveError(null);

    const userTurn: InteractionTurn = {
      id: 'turn_user_' + Date.now(),
      role: 'user',
      content: prompt,
      timestamp: Date.now(),
    };

    // Auto title generation for the first turn if untitled
    const updatedTitle =
      activeInteraction.turns.length === 0 &&
      (activeInteraction.title === 'New Reflection' || !activeInteraction.title)
        ? prompt.slice(0, 42).trim() + (prompt.length > 42 ? '...' : '')
        : activeInteraction.title;

    // Prepare updated state with user turn
    const interactionWithUserTurn: InteractionDoc = {
      ...activeInteraction,
      title: updatedTitle,
      mode,
      turns: [...activeInteraction.turns, userTurn],
      updatedAt: Date.now(),
    };

    setActiveInteraction(interactionWithUserTurn);

    try {
      // Call server-side Gemini endpoint with resilient fallback ladder
      const response = await fetch('/api/gemini/reflect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          history: activeInteraction.turns.map((t) => ({
            role: t.role,
            content: t.content,
          })),
          mode,
          generateSummary: true,
        }),
      });

      if (!response.ok) {
        const errorJson = await response.json().catch(() => ({}));
        throw new Error(errorJson.error || `Server returned ${response.status}`);
      }

      const data = await response.json();

      const geminiTurn: InteractionTurn = {
        id: 'turn_gemini_' + Date.now(),
        role: 'gemini',
        content: data.text || 'Reflecting on your insights...',
        timestamp: Date.now(),
      };

      // Merge new turns, summary, tags, and model used
      const finalInteraction: InteractionDoc = {
        ...interactionWithUserTurn,
        summary: data.summary || interactionWithUserTurn.summary,
        tags: data.tags && data.tags.length > 0 ? data.tags : interactionWithUserTurn.tags,
        modelUsed: data.modelUsed || 'gemini-3.6-flash',
        turns: [...interactionWithUserTurn.turns, geminiTurn],
        updatedAt: Date.now(),
      };

      // Guaranteed Transaction Verification: Persist to Firestore
      await handleUpdateInteraction(finalInteraction);
    } catch (error: any) {
      console.error('Gemini interaction processing error:', error);
      pendingSaveRef.current = interactionWithUserTurn;
      setSaveError(
        'Gemini reflection notice: ' +
          (error.message || 'Network error while contacting AI engine.') +
          ' Your prompt is saved in this active session.'
      );
      throw error;
    } finally {
      setIsGenerating(false);
    }
  };

  // Auth loading state
  if (authLoading) {
    return (
      <div className="min-h-screen bg-stone-100 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 rounded-xl bg-stone-900 text-amber-300 flex items-center justify-center mx-auto shadow-xs">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <p className="text-xs font-medium text-stone-700">
            Initializing Authenticated Workspace...
          </p>
        </div>
      </div>
    );
  }

  // If user is not authenticated, show Landing Page
  if (!currentUser) {
    return (
      <LandingPage
        onGoogleSignIn={handleGoogleSignIn}
        onDemoSignIn={handleDemoSignIn}
        authError={authError}
      />
    );
  }

  // Main Dashboard View (User Authenticated)
  return (
    <div className="h-screen flex flex-col bg-stone-100 overflow-hidden font-sans text-stone-900 antialiased">
      {/* Top Navbar */}
      <Navbar
        user={currentUser}
        onSignOut={handleSignOut}
        onNewReflection={handleNewReflection}
        isSaving={isSaving}
      />

      {/* Main App Layout */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Mobile Sidebar Toggle Button */}
        <button
          id="mobile-sidebar-toggle"
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="md:hidden fixed bottom-4 left-4 z-30 bg-stone-900 text-white p-3 rounded-full shadow-lg flex items-center justify-center"
          title="Toggle past reflections"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* History Sidebar */}
        <HistorySidebar
          interactions={interactions}
          activeInteractionId={activeInteractionId}
          onSelectInteraction={handleSelectInteraction}
          onNewReflection={handleNewReflection}
          onDeleteInteraction={handleDeleteInteraction}
          isOpen={sidebarOpen}
          onToggle={() => setSidebarOpen(false)}
        />

        {/* Central Workspace */}
        {activeInteraction ? (
          <JournalWorkspace
            currentInteraction={activeInteraction}
            onUpdateInteraction={handleUpdateInteraction}
            onSendPrompt={handleSendPrompt}
            isGenerating={isGenerating}
            saveError={saveError}
            onRetrySave={handleRetrySave}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center bg-white p-8 text-center">
            <div className="max-w-md space-y-3">
              <Sparkles className="w-8 h-8 mx-auto text-amber-500" />
              <h3 className="text-base font-semibold text-stone-900">
                Ready for your next reflection
              </h3>
              <p className="text-xs text-stone-700">
                Click "+ New Reflection" to begin a fresh conversation with Gemini 3.6 Flash.
              </p>
              <button
                onClick={handleNewReflection}
                className="inline-flex items-center px-4 py-2 bg-stone-900 text-white text-xs font-medium rounded-lg hover:bg-stone-800 transition-colors shadow-xs"
              >
                + Start Reflection
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

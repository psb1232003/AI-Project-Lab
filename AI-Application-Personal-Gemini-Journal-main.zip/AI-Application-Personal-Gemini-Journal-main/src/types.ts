export type ReflectionMode = 'reflection' | 'summary' | 'brainstorm' | 'journal';

export interface InteractionTurn {
  id: string;
  role: 'user' | 'gemini';
  content: string;
  timestamp: number;
}

export interface InteractionDoc {
  id: string;
  userId: string;
  title: string;
  summary: string;
  tags: string[];
  mode: ReflectionMode;
  modelUsed?: string;
  turns: InteractionTurn[];
  createdAt: number;
  updatedAt: number;
}

export interface UserProfile {
  uid: string;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
  isAnonymous?: boolean;
}

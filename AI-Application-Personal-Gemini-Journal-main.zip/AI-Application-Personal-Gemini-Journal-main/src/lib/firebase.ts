import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  signInAnonymously,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  getDoc,
  deleteDoc,
  query,
  orderBy,
  onSnapshot,
  Firestore,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { InteractionDoc, UserProfile } from '../types';

// Initialize Firebase App
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Firebase Auth
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Initialize Cloud Firestore using the configured database ID
export const db: Firestore = getFirestore(
  app,
  firebaseConfig.firestoreDatabaseId || '(default)'
);

/**
 * Production Directive: Strict Undefined-Stripping (Zero-Crash Payload Hygiene)
 * Eliminates all undefined values before passing payloads to Firestore SDK.
 */
export function stripUndefined<T>(obj: T): T {
  if (obj === null || obj === undefined) {
    return obj;
  }
  return JSON.parse(
    JSON.stringify(obj, (_key, value) => (value === undefined ? null : value))
  );
}

/**
 * Sign In with Google popup flow with friendly fallback
 */
export async function signInWithGoogle(): Promise<User> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error: any) {
    console.error('Google Sign-In popup error:', error);
    // If popup was blocked or closed, give descriptive error
    if (error.code === 'auth/popup-blocked') {
      throw new Error('Sign-in popup was blocked by your browser. Please allow popups or use Demo Account mode.');
    }
    if (error.code === 'auth/popup-closed-by-user') {
      throw new Error('Sign-in was cancelled before completion.');
    }
    throw error;
  }
}

/**
 * Anonymous / Demo Session sign-in for seamless preview evaluation
 */
export async function signInAsDemo(): Promise<User> {
  try {
    const result = await signInAnonymously(auth);
    return result.user;
  } catch (error: any) {
    console.error('Anonymous sign-in error:', error);
    throw new Error('Could not establish demo session. ' + (error.message || ''));
  }
}

/**
 * Sign Out flow
 */
export async function logOut(): Promise<void> {
  await signOut(auth);
}

/**
 * Path Generator for User Data Isolation:
 * Strictly bound to /users/{userId}/interactions/{interactionId}
 */
export function getUserInteractionsRef(userId: string) {
  if (!userId) throw new Error('User ID is required for data isolation.');
  return collection(db, 'users', userId, 'interactions');
}

export function getUserInteractionDocRef(userId: string, interactionId: string) {
  if (!userId || !interactionId) {
    throw new Error('User ID and Interaction ID are required for document reference.');
  }
  return doc(db, 'users', userId, 'interactions', interactionId);
}

/**
 * Guaranteed Transaction Verification:
 * Writes sanitized payload with strict undefined-stripping to Firestore.
 */
export async function saveUserInteraction(
  userId: string,
  interaction: InteractionDoc
): Promise<void> {
  if (!userId) throw new Error('Cannot persist without authenticated user ID.');
  const docRef = getUserInteractionDocRef(userId, interaction.id);
  const sanitizedPayload = stripUndefined({
    ...interaction,
    updatedAt: Date.now(),
  });
  await setDoc(docRef, sanitizedPayload, { merge: true });
}

/**
 * Delete a user interaction document
 */
export async function deleteUserInteraction(
  userId: string,
  interactionId: string
): Promise<void> {
  if (!userId || !interactionId) return;
  const docRef = getUserInteractionDocRef(userId, interactionId);
  await deleteDoc(docRef);
}

export function mapFirebaseUser(user: User | null): UserProfile | null {
  if (!user) return null;
  return {
    uid: user.uid,
    displayName: user.displayName || (user.isAnonymous ? 'Demo Reflective User' : 'Journal User'),
    email: user.email || (user.isAnonymous ? 'demo-session@firestore.local' : 'user@authenticated.local'),
    photoURL: user.photoURL || null,
    isAnonymous: user.isAnonymous,
  };
}

import React from 'react';
import { UserProfile } from '../types';
import { LogOut, ShieldCheck, Sparkles, User as UserIcon } from 'lucide-react';

interface NavbarProps {
  user: UserProfile;
  onSignOut: () => void;
  onNewReflection: () => void;
  isSaving?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  onSignOut,
  onNewReflection,
  isSaving,
}) => {
  return (
    <header
      id="app-header"
      className="bg-stone-50 border-b border-stone-200 sticky top-0 z-30 px-4 sm:px-6 py-3"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Left: Brand & Badges */}
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-stone-900 flex items-center justify-center text-stone-100 shadow-xs">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-base font-semibold text-stone-900 tracking-tight">
                Gemini Reflection Journal
              </h1>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-900 border border-amber-200">
                Gemini 3.6 Flash
              </span>
            </div>
            <p className="text-xs text-stone-700 flex items-center space-x-1.5 mt-0.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Isolated to UID:</span>
              <code className="bg-stone-200 text-stone-800 px-1 py-0.2 rounded font-mono text-[10px]">
                {user.uid.slice(0, 10)}...
              </code>
            </p>
          </div>
        </div>

        {/* Right: Actions and User Profile */}
        <div className="flex items-center space-x-3">
          {isSaving && (
            <div className="hidden sm:flex items-center space-x-1.5 text-xs text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-md">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
              <span>Syncing Firestore...</span>
            </div>
          )}

          <button
            id="new-reflection-btn"
            onClick={onNewReflection}
            className="text-xs sm:text-sm font-medium bg-stone-900 hover:bg-stone-800 text-white px-3 sm:px-4 py-1.5 rounded-md transition-colors shadow-xs"
          >
            + New Reflection
          </button>

          {/* User Info Avatar & Sign Out */}
          <div className="flex items-center space-x-2 pl-2 border-l border-stone-200">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'User'}
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-full border border-stone-300 object-cover"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-stone-200 text-stone-700 flex items-center justify-center font-medium text-xs">
                {user.displayName ? user.displayName.charAt(0).toUpperCase() : <UserIcon className="w-4 h-4" />}
              </div>
            )}

            <div className="hidden md:block text-left">
              <p className="text-xs font-medium text-stone-900 max-w-[120px] truncate">
                {user.displayName || 'Reflector'}
              </p>
              <p className="text-[10px] text-stone-700 max-w-[120px] truncate">
                {user.email || 'Authenticated'}
              </p>
            </div>

            <button
              id="sign-out-btn"
              onClick={onSignOut}
              title="Sign Out"
              className="p-1.5 text-stone-700 hover:text-stone-900 hover:bg-stone-100 rounded-md transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

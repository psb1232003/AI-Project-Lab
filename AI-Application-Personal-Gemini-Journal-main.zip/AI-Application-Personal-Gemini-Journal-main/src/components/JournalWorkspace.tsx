import React, { useState, useEffect, useRef } from 'react';
import { InteractionDoc, ReflectionMode } from '../types';
import {
  Send,
  Sparkles,
  Bot,
  User,
  Copy,
  Check,
  Download,
  AlertTriangle,
  Lightbulb,
  FileText,
  Compass,
  PenTool,
  RotateCw,
} from 'lucide-react';

interface JournalWorkspaceProps {
  currentInteraction: InteractionDoc;
  onUpdateInteraction: (updated: InteractionDoc) => Promise<void>;
  onSendPrompt: (prompt: string, mode: ReflectionMode) => Promise<void>;
  isGenerating: boolean;
  saveError: string | null;
  onRetrySave: () => void;
}

const REFLECTION_MODES: {
  id: ReflectionMode;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}[] = [
  {
    id: 'reflection',
    label: 'Deep Reflection',
    icon: Compass,
    description: 'Empathetic, philosophical perspective exploring motivations & growth.',
  },
  {
    id: 'summary',
    label: 'Executive Summary',
    icon: FileText,
    description: 'Concise syntheses, bulleted key takeaways, and action items.',
  },
  {
    id: 'brainstorm',
    label: 'Brainstorm & Next Steps',
    icon: Lightbulb,
    description: 'Creative exploration, alternate angles, and practical roadmaps.',
  },
  {
    id: 'journal',
    label: 'Freeflow Journal',
    icon: PenTool,
    description: 'Open-ended exploratory dialogue to unpack thoughts without judgment.',
  },
];

const SUGGESTED_PROMPTS = [
  'Reflect on a challenging decision I faced today and help me examine different perspectives.',
  'Help me clarify my highest-leverage goals for this week and identify what to let go of.',
  'I am feeling a bit scattered with competing tasks; help me synthesize my focus.',
  'Brainstorm creative angles for a personal project I have been procrastinating on.',
];

export const JournalWorkspace: React.FC<JournalWorkspaceProps> = ({
  currentInteraction,
  onUpdateInteraction,
  onSendPrompt,
  isGenerating,
  saveError,
  onRetrySave,
}) => {
  const [inputText, setInputText] = useState('');
  const [copiedTurnId, setCopiedTurnId] = useState<string | null>(null);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleText, setTitleText] = useState(currentInteraction.title);
  const turnsEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setTitleText(currentInteraction.title);
  }, [currentInteraction.title]);

  useEffect(() => {
    turnsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentInteraction.turns, isGenerating]);

  const handleTitleSubmit = () => {
    setIsEditingTitle(false);
    if (titleText.trim() && titleText !== currentInteraction.title) {
      onUpdateInteraction({
        ...currentInteraction,
        title: titleText.trim(),
      });
    }
  };

  const handleModeChange = (newMode: ReflectionMode) => {
    onUpdateInteraction({
      ...currentInteraction,
      mode: newMode,
    });
  };

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed || isGenerating) return;

    // Preserve input temporarily until successful generation & save
    try {
      await onSendPrompt(trimmed, currentInteraction.mode);
      setInputText('');
    } catch (err) {
      // In case of failure, input buffer remains preserved for retry
      console.error('Send failed, preserving input buffer:', err);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTurnId(id);
    setTimeout(() => setCopiedTurnId(null), 2000);
  };

  const exportAsMarkdown = () => {
    let md = `# ${currentInteraction.title}\n\n`;
    md += `**Date:** ${new Date(currentInteraction.createdAt).toLocaleString()}\n`;
    md += `**Mode:** ${currentInteraction.mode}\n\n`;
    if (currentInteraction.summary) {
      md += `### Executive Summary\n${currentInteraction.summary}\n\n---\n\n`;
    }
    currentInteraction.turns.forEach((turn) => {
      const author = turn.role === 'user' ? '### 📝 Reflection (You)' : '### ✨ Gemini Insight';
      md += `${author}\n\n${turn.content}\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentInteraction.title.toLowerCase().replace(/[^a-z0-9]/g, '_')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-white overflow-hidden">
      {/* Top Workspace Header */}
      <div className="border-b border-stone-200 px-4 sm:px-6 py-3 bg-stone-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
        <div className="flex-1 min-w-0">
          {isEditingTitle ? (
            <input
              id="reflection-title-input"
              type="text"
              value={titleText}
              onChange={(e) => setTitleText(e.target.value)}
              onBlur={handleTitleSubmit}
              onKeyDown={(e) => e.key === 'Enter' && handleTitleSubmit()}
              autoFocus
              className="text-base font-semibold text-stone-900 border border-stone-300 rounded px-2 py-0.5 bg-white w-full max-w-md focus:outline-hidden focus:border-stone-500"
            />
          ) : (
            <div className="flex items-center space-x-2">
              <h2
                id="reflection-title-display"
                onClick={() => setIsEditingTitle(true)}
                title="Click to rename"
                className="text-base font-semibold text-stone-900 truncate hover:text-stone-600 cursor-pointer"
              >
                {currentInteraction.title || 'Untitled Reflection'}
              </h2>
              <span className="text-[10px] text-stone-700 bg-stone-200/70 px-1.5 py-0.5 rounded cursor-pointer" onClick={() => setIsEditingTitle(true)}>
                Rename
              </span>
            </div>
          )}

          <div className="flex items-center space-x-3 text-xs text-stone-700 mt-1">
            <span>
              {new Date(currentInteraction.createdAt).toLocaleDateString([], {
                month: 'short',
                day: 'numeric',
                year: 'numeric',
              })}
            </span>
            <span>•</span>
            <span className="inline-flex items-center text-emerald-700 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5"></span>
              Firestore Isolated
            </span>
            {currentInteraction.modelUsed && (
              <>
                <span>•</span>
                <span className="font-mono text-[11px] text-stone-700">
                  {currentInteraction.modelUsed}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Header Actions */}
        <div className="flex items-center space-x-2">
          <button
            id="export-markdown-btn"
            onClick={exportAsMarkdown}
            title="Download as Markdown"
            className="flex items-center space-x-1 text-xs font-medium text-stone-700 hover:text-stone-900 bg-white border border-stone-200 hover:border-stone-300 px-2.5 py-1.5 rounded-md transition-colors shadow-2xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export Entry</span>
          </button>
        </div>
      </div>

      {/* Mode Selector Tabs */}
      <div className="border-b border-stone-200 bg-white px-4 sm:px-6 py-2 shrink-0">
        <div className="flex items-center space-x-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <span className="text-xs font-medium text-stone-700 mr-2 shrink-0">Gemini Stance:</span>
          {REFLECTION_MODES.map((mode) => {
            const Icon = mode.icon;
            const isSelected = currentInteraction.mode === mode.id;
            return (
              <button
                key={mode.id}
                id={`mode-tab-${mode.id}`}
                onClick={() => handleModeChange(mode.id)}
                title={mode.description}
                className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-all shrink-0 ${
                  isSelected
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'text-stone-700 hover:text-stone-900 hover:bg-stone-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{mode.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Error Banner with Retry Save Option */}
      {saveError && (
        <div
          id="workspace-save-error"
          className="mx-4 sm:mx-6 mt-3 p-3 bg-amber-50 border border-amber-300 rounded-lg flex items-center justify-between text-xs text-amber-900"
        >
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
            <span>{saveError}</span>
          </div>
          <button
            id="retry-save-btn"
            onClick={onRetrySave}
            className="flex items-center space-x-1 font-semibold text-amber-900 bg-amber-200 hover:bg-amber-300 px-2.5 py-1 rounded transition-colors"
          >
            <RotateCw className="w-3 h-3" />
            <span>Retry Save</span>
          </button>
        </div>
      )}

      {/* Conversation Turns Scroll Area */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6 space-y-6">
        {/* Executive Summary Card if generated */}
        {currentInteraction.summary && (
          <div
            id="executive-summary-card"
            className="bg-stone-50 border border-stone-200 rounded-xl p-4 text-stone-800 shadow-2xs"
          >
            <div className="flex items-center space-x-2 text-xs font-semibold text-stone-900 mb-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Session Reflection Synthesis</span>
            </div>
            <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
              {currentInteraction.summary}
            </p>
            {currentInteraction.tags && currentInteraction.tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-3 pt-2 border-t border-stone-200/60">
                {currentInteraction.tags.map((t, i) => (
                  <span
                    key={i}
                    className="px-2 py-0.5 bg-white border border-stone-200 text-stone-700 rounded-md text-[11px] font-medium"
                  >
                    #{t}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Empty State / Prompt Suggestions */}
        {(!currentInteraction.turns || currentInteraction.turns.length === 0) && (
          <div className="max-w-2xl mx-auto py-8 text-center">
            <div className="w-12 h-12 rounded-2xl bg-stone-100 border border-stone-200 flex items-center justify-center mx-auto text-stone-800 mb-3">
              <Sparkles className="w-6 h-6 text-amber-500" />
            </div>
            <h3 className="text-base font-semibold text-stone-900">
              Start your conversation with Gemini
            </h3>
            <p className="text-xs sm:text-sm text-stone-700 mt-1 max-w-md mx-auto leading-relaxed">
              Write whatever is on your mind. You can reflect on events, unpack decisions, or explore ideas.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mt-6 text-left">
              {SUGGESTED_PROMPTS.map((prompt, i) => (
                <button
                  key={i}
                  id={`suggested-prompt-${i}`}
                  onClick={() => setInputText(prompt)}
                  className="p-3 rounded-lg border border-stone-200 bg-stone-50 hover:bg-white hover:border-stone-300 text-stone-700 hover:text-stone-900 text-xs transition-all text-left shadow-2xs group"
                >
                  <span className="font-medium text-stone-900 block mb-1 group-hover:text-amber-700">
                    Prompt Idea {i + 1}
                  </span>
                  <span className="leading-snug block">{prompt}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Conversation Turns */}
        {currentInteraction.turns?.map((turn) => {
          const isUser = turn.role === 'user';
          return (
            <div
              key={turn.id}
              id={`turn-${turn.id}`}
              className={`flex items-start space-x-3 max-w-3xl ${
                isUser ? 'ml-auto flex-row-reverse space-x-reverse' : 'mr-auto'
              }`}
            >
              {/* Avatar */}
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs ${
                  isUser
                    ? 'bg-stone-900 text-white'
                    : 'bg-amber-100 text-amber-900 border border-amber-200'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-amber-700" />}
              </div>

              {/* Message Bubble */}
              <div
                className={`group relative rounded-xl px-4 py-3 text-xs sm:text-sm leading-relaxed max-w-2xl transition-shadow ${
                  isUser
                    ? 'bg-stone-900 text-stone-100 shadow-xs'
                    : 'bg-stone-50 border border-stone-200 text-stone-800 shadow-2xs'
                }`}
              >
                {/* Author Label & Timestamp */}
                <div
                  className={`flex items-center justify-between text-[11px] mb-1.5 ${
                    isUser ? 'text-stone-400' : 'text-stone-700'
                  }`}
                >
                  <span className="font-medium">
                    {isUser ? 'Your Journal Reflection' : 'Gemini 3.6 Flash'}
                  </span>
                  <span>
                    {new Date(turn.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                {/* Text Content */}
                <div className="whitespace-pre-wrap font-sans text-xs sm:text-sm">
                  {turn.content}
                </div>

                {/* Copy Button */}
                <button
                  id={`copy-turn-${turn.id}`}
                  onClick={() => copyToClipboard(turn.content, turn.id)}
                  title="Copy text"
                  className={`absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1 rounded transition-all ${
                    isUser
                      ? 'text-stone-400 hover:text-white hover:bg-stone-800'
                      : 'text-stone-400 hover:text-stone-700 hover:bg-stone-200'
                  }`}
                >
                  {copiedTurnId === turn.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>
          );
        })}

        {/* Gemini Generating Indicator */}
        {isGenerating && (
          <div
            id="gemini-generating-indicator"
            className="flex items-start space-x-3 max-w-3xl mr-auto"
          >
            <div className="w-7 h-7 rounded-lg bg-amber-100 border border-amber-200 text-amber-700 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 animate-pulse" />
            </div>
            <div className="bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 text-xs text-stone-700 flex items-center space-x-2 shadow-2xs">
              <Sparkles className="w-4 h-4 text-amber-600 animate-spin" />
              <span>Gemini 3.6 Flash is synthesizing insights and reflections...</span>
            </div>
          </div>
        )}

        <div ref={turnsEndRef} />
      </div>

      {/* Bottom Composer */}
      <div className="border-t border-stone-200 p-4 sm:px-6 sm:py-4 bg-stone-50/70 shrink-0">
        <form onSubmit={handleSend} className="max-w-4xl mx-auto relative">
          <div className="bg-white border border-stone-300 rounded-xl focus-within:border-stone-500 focus-within:ring-1 focus-within:ring-stone-400 shadow-xs transition-all overflow-hidden">
            <textarea
              id="reflection-prompt-input"
              ref={textareaRef}
              rows={3}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="What are you reflecting on today? Express thoughts, ask for perspective, or unpack an idea..."
              disabled={isGenerating}
              className="w-full px-4 py-3 text-xs sm:text-sm text-stone-900 placeholder-stone-400 resize-none focus:outline-hidden"
            />

            <div className="flex items-center justify-between px-3.5 py-2 bg-stone-50/60 border-t border-stone-100">
              <div className="flex items-center space-x-2 text-[11px] text-stone-700">
                <span className="hidden sm:inline">Press</span>
                <kbd className="px-1.5 py-0.5 bg-stone-200 text-stone-700 rounded text-[10px] font-mono">
                  Enter
                </kbd>
                <span className="hidden sm:inline">to send,</span>
                <kbd className="px-1.5 py-0.5 bg-stone-200 text-stone-700 rounded text-[10px] font-mono">
                  Shift+Enter
                </kbd>
                <span className="hidden sm:inline">for newline</span>
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-[11px] text-stone-700 font-mono">
                  {inputText.length} / 10000
                </span>

                <button
                  id="submit-prompt-btn"
                  type="submit"
                  disabled={!inputText.trim() || isGenerating}
                  className="flex items-center space-x-1.5 bg-stone-900 hover:bg-stone-800 disabled:opacity-40 text-white text-xs font-medium px-4 py-1.5 rounded-lg transition-colors shadow-xs"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isGenerating ? 'Thinking...' : 'Reflect'}</span>
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { InteractionDoc } from '../types';
import {
  BookOpen,
  Search,
  Trash2,
  Calendar,
  MessageSquare,
  Sparkles,
  ChevronRight,
  Plus,
} from 'lucide-react';

interface HistorySidebarProps {
  interactions: InteractionDoc[];
  activeInteractionId: string | null;
  onSelectInteraction: (id: string) => void;
  onNewReflection: () => void;
  onDeleteInteraction: (id: string, e: React.MouseEvent) => void;
  isOpen: boolean;
  onToggle: () => void;
}

export const HistorySidebar: React.FC<HistorySidebarProps> = ({
  interactions,
  activeInteractionId,
  onSelectInteraction,
  onNewReflection,
  onDeleteInteraction,
  isOpen,
  onToggle,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = interactions.filter((item) => {
    const q = searchQuery.toLowerCase();
    const titleMatch = item.title?.toLowerCase().includes(q);
    const summaryMatch = item.summary?.toLowerCase().includes(q);
    const tagsMatch = item.tags?.some((t) => t.toLowerCase().includes(q));
    const contentMatch = item.turns?.some((turn) => turn.content.toLowerCase().includes(q));
    return titleMatch || summaryMatch || tagsMatch || contentMatch;
  });

  const formatDate = (timestamp: number) => {
    if (!timestamp) return 'Just now';
    const date = new Date(timestamp);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 3600 * 24));

    if (diffDays === 0) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return date.toLocaleDateString([], { weekday: 'short' });
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-stone-900/20 backdrop-blur-xs z-20 md:hidden"
          onClick={onToggle}
        />
      )}

      <aside
        id="history-sidebar"
        className={`fixed md:static inset-y-0 left-0 z-20 w-72 sm:w-80 bg-stone-50 border-r border-stone-200 flex flex-col transition-transform duration-200 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Top Header & New Button */}
        <div className="p-3.5 border-b border-stone-200 flex flex-col space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-stone-900 font-semibold text-sm">
              <BookOpen className="w-4 h-4 text-stone-700" />
              <span>Past Reflections</span>
            </div>
            <span className="text-[11px] font-medium bg-stone-200 text-stone-700 px-2 py-0.5 rounded-full">
              {interactions.length} {interactions.length === 1 ? 'entry' : 'entries'}
            </span>
          </div>

          <button
            id="sidebar-new-btn"
            onClick={onNewReflection}
            className="w-full flex items-center justify-center space-x-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-medium py-2 px-3 rounded-lg transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create New Reflection</span>
          </button>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-stone-400" />
            <input
              id="search-reflections-input"
              type="text"
              placeholder="Search past thoughts & tags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-stone-200 rounded-md pl-8 pr-3 py-1.5 text-xs text-stone-800 placeholder-stone-400 focus:outline-hidden focus:border-stone-400"
            />
          </div>
        </div>

        {/* Scrollable Entry List */}
        <div className="flex-1 overflow-y-auto divide-y divide-stone-100 p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="p-6 text-center text-stone-700">
              <Sparkles className="w-6 h-6 mx-auto text-stone-400 mb-2" />
              <p className="text-xs font-medium">No reflections found</p>
              <p className="text-[11px] text-stone-700 mt-1">
                {searchQuery
                  ? 'Try a different search keyword.'
                  : 'Your past conversations with Gemini will be recorded here.'}
              </p>
            </div>
          ) : (
            filtered.map((entry) => {
              const isActive = entry.id === activeInteractionId;
              const turnCount = entry.turns ? entry.turns.length : 0;

              return (
                <div
                  key={entry.id}
                  id={`history-item-${entry.id}`}
                  onClick={() => onSelectInteraction(entry.id)}
                  className={`group relative p-3 rounded-lg cursor-pointer transition-all ${
                    isActive
                      ? 'bg-white border border-stone-300 shadow-xs ring-1 ring-stone-300'
                      : 'hover:bg-stone-100/80 border border-transparent'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <h3
                      className={`text-xs font-semibold line-clamp-1 flex-1 ${
                        isActive ? 'text-stone-900' : 'text-stone-700 group-hover:text-stone-900'
                      }`}
                    >
                      {entry.title || 'Untitled Reflection'}
                    </h3>

                    <button
                      id={`delete-entry-${entry.id}`}
                      onClick={(e) => onDeleteInteraction(entry.id, e)}
                      title="Delete Entry"
                      className="opacity-0 group-hover:opacity-100 p-1 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-opacity"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {entry.summary && (
                    <p className="text-[11px] text-stone-700 line-clamp-2 mt-1 leading-relaxed">
                      {entry.summary}
                    </p>
                  )}

                  <div className="flex items-center justify-between mt-2 pt-1 border-t border-stone-100 text-[10px] text-stone-700">
                    <span className="flex items-center space-x-1">
                      <Calendar className="w-3 h-3" />
                      <span>{formatDate(entry.updatedAt || entry.createdAt)}</span>
                    </span>

                    <span className="flex items-center space-x-1 font-medium text-stone-700">
                      <MessageSquare className="w-3 h-3" />
                      <span>{turnCount} turns</span>
                    </span>
                  </div>

                  {entry.tags && entry.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {entry.tags.slice(0, 3).map((tag, idx) => (
                        <span
                          key={idx}
                          className="px-1.5 py-0.2 bg-stone-100 border border-stone-200 text-stone-700 rounded text-[9px]"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-stone-200 bg-stone-100/60 text-[10px] text-stone-700 flex items-center justify-between">
          <span className="flex items-center space-x-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>Firestore Sync Active</span>
          </span>
          <span>Owner-only Rules</span>
        </div>
      </aside>
    </>
  );
};

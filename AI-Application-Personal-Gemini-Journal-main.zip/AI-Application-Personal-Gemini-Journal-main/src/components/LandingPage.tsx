import React, { useState } from 'react';
import { Shield, Sparkles, Database, Lock, KeyRound, ArrowRight, AlertCircle, CheckCircle2 } from 'lucide-react';

interface LandingPageProps {
  onGoogleSignIn: () => Promise<void>;
  onDemoSignIn: () => Promise<void>;
  authError: string | null;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onGoogleSignIn,
  onDemoSignIn,
  authError,
}) => {
  const [loadingGoogle, setLoadingGoogle] = useState(false);
  const [loadingDemo, setLoadingDemo] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const handleGoogle = async () => {
    setActionError(null);
    setLoadingGoogle(true);
    try {
      await onGoogleSignIn();
    } catch (err: any) {
      setActionError(err?.message || 'Google Sign-In failed.');
    } finally {
      setLoadingGoogle(false);
    }
  };

  const handleDemo = async () => {
    setActionError(null);
    setLoadingDemo(true);
    try {
      await onDemoSignIn();
    } catch (err: any) {
      setActionError(err?.message || 'Demo session initialization failed.');
    } finally {
      setLoadingDemo(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col justify-between text-stone-800">
      {/* Top Banner */}
      <header className="border-b border-stone-200 bg-white/70 backdrop-blur-xs px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-stone-900 flex items-center justify-center text-amber-300">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="font-semibold text-stone-900 text-sm tracking-tight">
              Gemini Reflection Journal
            </span>
          </div>
          <div className="flex items-center space-x-2 text-xs text-stone-700">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Firestore Isolation Active</span>
          </div>
        </div>
      </header>

      {/* Main Hero Card */}
      <main className="flex-1 flex items-center justify-center px-4 sm:px-6 py-12">
        <div className="max-w-xl w-full bg-white border border-stone-200 rounded-xl p-8 shadow-sm">
          {/* Card Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-stone-100 border border-stone-200 text-stone-900 mb-4">
              <Lock className="w-6 h-6 text-stone-700" />
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-stone-900">
              Your Private Mindful Journal
            </h2>
            <p className="text-stone-700 text-sm mt-2 max-w-md mx-auto leading-relaxed">
              Explore your thoughts, gain deep insights, and converse with Gemini 3.6 Flash.
              Every reflection is strictly isolated in Cloud Firestore under your own UID.
            </p>
          </div>

          {/* Error Banner */}
          {(authError || actionError) && (
            <div
              id="auth-error-banner"
              className="mb-6 p-3.5 bg-rose-50 border border-rose-200 rounded-lg flex items-start space-x-2.5 text-xs text-rose-800"
            >
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium">Authentication Notice</p>
                <p className="mt-0.5 text-rose-700">{authError || actionError}</p>
                <p className="mt-1 text-[11px] text-rose-600">
                  Tip: If popups are restricted in iframe preview, you can click "Start Sandbox Demo Session" below to evaluate the complete journal and Firestore persistence instantly.
                </p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-3">
            <button
              id="google-signin-btn"
              onClick={handleGoogle}
              disabled={loadingGoogle || loadingDemo}
              className="w-full flex items-center justify-center space-x-3 bg-stone-900 hover:bg-stone-800 text-white font-medium py-2.5 px-4 rounded-lg transition-colors shadow-xs disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="currentColor"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="currentColor"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="currentColor"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{loadingGoogle ? 'Connecting with Google...' : 'Sign in with Google'}</span>
            </button>

            <button
              id="demo-signin-btn"
              onClick={handleDemo}
              disabled={loadingGoogle || loadingDemo}
              className="w-full flex items-center justify-center space-x-2 bg-stone-100 hover:bg-stone-200 text-stone-800 font-medium py-2.5 px-4 rounded-lg transition-colors border border-stone-300 text-xs sm:text-sm disabled:opacity-50"
            >
              <KeyRound className="w-4 h-4 text-stone-700" />
              <span>{loadingDemo ? 'Initializing Demo...' : 'Start Sandbox Demo Session'}</span>
              <ArrowRight className="w-3.5 h-3.5 text-stone-700 ml-1" />
            </button>
          </div>

          {/* Security & Architecture Pillars */}
          <div className="mt-8 pt-6 border-t border-stone-200 grid grid-cols-1 gap-3.5 text-left">
            <div className="flex items-start space-x-3">
              <Shield className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-semibold text-stone-900">Zero-Leak Firestore Rules</h4>
                <p className="text-[11px] text-stone-700 mt-0.5">
                  Interactions saved at <code className="text-stone-800 font-mono">/users/{'{userId}'}/interactions</code>. Strict Firestore rules prevent any other user from accessing your data.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-semibold text-stone-900">Resilient Gemini 3.6 Flash Engine</h4>
                <p className="text-[11px] text-stone-700 mt-0.5">
                  Multi-turn reflections powered by an automated fallback ladder with high availability and intelligent summarization.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Database className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-semibold text-stone-900">Guaranteed Transaction Verification</h4>
                <p className="text-[11px] text-stone-700 mt-0.5">
                  Strict undefined stripping and input-to-save verification keep your journaling buffer safe and resilient.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-200 bg-white/50 px-6 py-4 text-center text-xs text-stone-700">
        <p>Built with Google Cloud Firestore, Firebase Auth, and Gemini 3.6 Flash API</p>
      </footer>
    </div>
  );
};
